<?php
// specific instalation configuration
?>
