<?php
// specific instalation configuration

// database configuration
define('DB_USERNAME', 'creamcrm');
define('DB_PASSWORD', 'creamcrm');
define('DB_HOST', 'localhost');
//define('DB_NAME', 'db_creamcrm');
define('DB_NAME', 'goautodial');
define('DB_PORT', '3306');

// other configuration parameters			
define('CRM_ADMIN_EMAIL', 'admin_cream@goautodial.com');
?>
